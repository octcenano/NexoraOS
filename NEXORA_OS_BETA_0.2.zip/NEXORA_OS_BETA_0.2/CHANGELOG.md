# Changelog

## 0.2.0-beta (revisado)

Corrige el paquete anterior, cuyo código no coincidía con el documento de traspaso y cuya suite de tests no arrancaba.

### Corregido
- Los tests importaban `ModeRegistry`, `calculate_hybrid_profile` y `BaseAgent`, que no existían; `AccountHub` y `BrowserConnector` tenían otra API distinta a la usada por los tests. Ahora existen y los 9 tests originales pasan sin modificarse.
- `MeteorologyAgent` importaba una clase inexistente y devolvía datos fijos presentados como "observación verificada". Ahora los datos simulados se etiquetan `simulated: True` y existe un proveedor real (Open-Meteo, opt-in).
- `LocalAIEngine` afirmaba soportar Ollama/llama.cpp/LocalAI pero solo devolvía texto simulado, y `is_connected` era siempre `True`. Ahora implementa los tres backends.
- `SecureVault` era un diccionario sin política ni validación; ahora tiene backends explícitos y no filtra valores en `repr`.
- La CLI usaba funciones que no existían y valores fijos (4 núcleos, 8 GB); ahora detecta el hardware.
- `defaults.json` y `pyproject.toml` seguían en 0.1; ahora la versión sale de `nexora.__version__`.
- Faltaban `__init__.py` en 4 subpaquetes; el zip tenía una carpeta duplicada anidada.
- `diagnostics.health` devolvía estados fijos; ahora hace comprobaciones reales (aislamiento, config, vault, motor IA, navegadores).

### Añadido
- `core.config` (carga y validación; rechaza secretos), `AgentMessage` y `share_with` con aprobación explícita, estados y permisos reales en el Account Hub, comandos CLI `health`, `weather`, `ask`, opciones `dashboard --mode/--json`, 66 tests nuevos.
- `IsolatedAgent` se sustituye por `BaseAgent` (con memoria `remember/recall`).
