# Roadmap

Leyenda: `[x]` hecho · `[~]` parcial · `[ ]` pendiente

## Beta 0.1 — Base
- [x] Nombre e identidad inicial NEXORA OS
- [x] Arquitectura modular documentada
- [x] Modos registrados
- [x] Aislamiento de agentes definido
- [x] Perfiles híbridos prototipados
- [x] Account Hub y contratos de navegador
- [x] Pruebas unitarias base

## Beta 0.2 — Integración
- [~] Interfaz gráfica real — modelo de estado + vista de terminal; falta la ventana gráfica
- [x] Proveedor de IA local configurable — Ollama, llama.cpp, LocalAI (probado con servidor de prueba, no con modelos reales)
- [~] Almacén seguro de credenciales — RAM + `keyring` opcional (probado con doble de prueba)
- [ ] Conectores OAuth/API reales — solo ciclo de vida y permisos
- [ ] Firefox y LibreWolf probados — solo detección en PATH
- [~] Agente meteorológico conectado a fuentes verificables — Open-Meteo opt-in, no probado en vivo; AEMET pendiente

## Beta 0.3 — Sistema
- [ ] Cerrar los pendientes de Beta 0.2 (arriba)
- [ ] Base Arch/ISO reproducible
- [ ] Instalador gráfico
- [ ] Servicios systemd mínimos y medidos
- [ ] Watchdogs con límites y recuperación segura
- [ ] Pruebas de instalación en VM y hardware

## Beta 1.0
- [ ] Auditoría externa
- [ ] Accesibilidad y UX/UI completas
- [ ] Actualizaciones y rollback verificados
- [ ] Documentación de instalación y recuperación
