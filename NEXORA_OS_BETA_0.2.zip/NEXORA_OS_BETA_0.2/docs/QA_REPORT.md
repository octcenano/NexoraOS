# Informe QA — Beta 0.2

## Verificado en esta revisión
- `python -m unittest discover -s tests -v` → **75 tests, OK** (Python 3.12.3, Linux). Incluye los 9 tests originales sin modificar y 66 nuevos.
- Los tests detectan roturas reales: se rompieron a propósito el aislamiento de memoria, la comprobación de endpoints locales y la regla de autorización del Account Hub, y cada rotura hizo fallar la suite.
- El motor IA (Ollama y API compatible con OpenAI) se probó contra un servidor HTTP local que imita el formato de esas APIs.
- Open-Meteo se probó con respuestas simuladas inyectadas.
- `keyring` se probó con un doble de prueba.
- El paquete se construye (`pip wheel`, versión `0.2.0b0`) y se instala; fuera del repo necesita `NEXORA_CONFIG_DIR`.
- Sin credenciales reales ni tokens en el paquete; el validador de configuración rechaza secretos.

## NO verificado
- Open-Meteo real (el entorno de pruebas no tenía red).
- Ollama, llama.cpp o LocalAI reales con un modelo cargado.
- `keyring` real con un almacén de secretos del sistema.
- Python 3.10 y 3.11 (solo se probó 3.12).
- Firefox/LibreWolf (solo se detecta si hay un ejecutable en el PATH).
- Arch Linux ni hardware físico.

## Limitaciones conocidas
- No es una ISO ni instala un sistema operativo; no hay instalador.
- No hay ventana gráfica: el dashboard es un modelo de estado y una vista de terminal.
- No hay OAuth ni integración real con navegadores.
- AEMET OpenData no está implementado.
- El aislamiento de agentes es lógico, no de procesos.
- Forge, Security, Creator y Office son agentes stub.
- Watchdogs y demonios systemd siguen pendientes.
- Los límites por perfil son orientativos, no medidos.

## Revisión UX/UI
La interfaz gráfica aún no está implementada. La CLI y la vista de terminal sirven para validar modos, perfiles y estado; no representan la experiencia final.
