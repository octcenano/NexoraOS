# Account Hub

Estados de conexión: `not_configured`, `pending_authorization`, `connected`, `expired`, `revoked`, `error`.

## Ciclo de vida implementado
- `register_connection(service, tipo, scopes, secret_ref=None)` → `pending_authorization` (siempre sin autorizar; si ya existía, se reinicia).
- `grant(service)` → `connected`. Solo desde `pending_authorization`: es el punto donde la UI registrará el consentimiento tras un flujo oficial.
- `mark_expired` (solo desde `connected`), `mark_error`, `revoke` → `revoked`. Una conexión revocada no puede volver a autorizarse sin volver a registrarla.
- `may_access(service, scope)`: verdadero solo si está `connected` y el scope fue declarado.

## Métodos de conexión previstos
- OAuth/API oficial.
- Conector local documentado con consentimiento explícito.
- Importación manual de configuración no secreta.

## Secretos
No se almacenan contraseñas en texto plano ni en el Hub. Los secretos van en `nexora.core.vault` (RAM por defecto; almacén del SO con `keyring`) y el Hub guarda solo la referencia. Beta 0.2 incluye contratos y ciclo de vida, **no integraciones reales**.
