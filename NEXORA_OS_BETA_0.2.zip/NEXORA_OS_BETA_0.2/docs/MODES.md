# Modos de NEXORA

- **Forge**: desarrollo, proyectos, herramientas y modelos locales.
- **Meteorology**: agente meteorológico independiente; observaciones, modelos, alertas y sondeos mediante proveedores validados. En Beta 0.2: observación actual (simulada por defecto, Open-Meteo opt-in). Sin alertas ni sondeos todavía.
- **Security**: diagnóstico defensivo y auditorías en sistemas autorizados.
- **Creator**: planificación y análisis de contenido digital.
- **Office**: documentos, estudio y productividad.

Cada modo puede tener dependencias, permisos, interfaz y memoria separados. El núcleo común solo proporciona servicios transversales. Forge, Security, Creator y Office son hoy agentes base (stub) con memoria aislada.
