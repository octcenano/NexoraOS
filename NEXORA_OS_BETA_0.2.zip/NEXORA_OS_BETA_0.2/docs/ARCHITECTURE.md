# Arquitectura NEXORA OS (Beta 0.2)

## Capas
1. **NEXORA Core**: configuración (`core.config`), registro de modos (`core.registry`), permisos (`core.permissions`), perfiles (`core.profiles`), motor IA local (`core.ai_engine`), vault (`core.vault`) y diagnóstico (`diagnostics.health`).
2. **Mode Runtime**: carga un modo sin mezclar su memoria privada con la de otros modos.
3. **Agent Runtime**: un agente por modo (`agents.base.BaseAgent`). Solo meteorología tiene lógica propia; el resto son agentes base (stub).
4. **Account Hub**: catálogo de conexiones y permisos revocables.
5. **Hardware/Profile Manager**: detección automática y sugerencias; el usuario puede fijar el perfil o los límites.
6. **UI Runtime**: modelo de estado del dashboard + vista de terminal. La GUI gráfica consumirá `render_layout()`.
7. **System Integration**: futura integración con systemd, paquetes, escritorio e instalador (no implementada).

## Aislamiento de agentes
Cada agente tiene su propia memoria privada (`agents/<mode>/`). No hay memoria compartida. El intercambio pasa por `AgentMessage` (origen, destino, propósito y datos seleccionados) y solo se emite con `user_approved=True`. El receptor lo recibe en una **bandeja de entrada**, nunca en su memoria privada.

> Alcance: el aislamiento es lógico (espacios de nombres y API dentro de un mismo proceso). No es una frontera de seguridad frente a código malicioso. El aislamiento por procesos/permisos del SO pertenece a Beta 0.3+.

## Secretos
- La configuración rechaza secretos (`core.config.find_secret_like`).
- `SecureVault` es la única vía prevista para credenciales. Backend por defecto: RAM. Backend persistente: almacén del SO vía `keyring`. No hay criptografía propia.
- El Account Hub solo guarda `secret_ref` (nombre de la entrada en el vault), nunca el secreto.

## Privacidad y red
- Telemetría desactivada.
- El motor IA solo acepta endpoints locales salvo `allow_remote` explícito, y no usa proxies.
- Las consultas de red del agente meteorológico son opt-in.

## Account Hub y navegadores
Firefox y LibreWolf son opciones de primera clase (`both` = ambos). La conexión se implementará preferentemente con OAuth/API oficial. Una integración local de navegador deberá usar mecanismos documentados y consentimiento explícito. No se extraerán cookies, contraseñas ni tokens de perfiles. Hoy solo se detecta si hay ejecutables en el PATH.

## Perfiles híbridos
El sistema detecta recursos y recomienda un perfil (`compact`, `balanced`, `expanded`). Los ajustes manuales tienen prioridad y, si superan lo recomendado, se muestra un aviso y se puede revertir con `--profile auto`. Ningún perfil debe aplicar cambios de kernel, red, energía o seguridad sin mostrar el cambio y permitir revertirlo. Los límites por perfil son orientativos, no medidos.

## Servicios persistentes
Los watchdogs y demonios se instalarán solo cuando exista una función concreta, consumo medido, política de reinicio y mecanismo de apagado. En Beta 0.2 siguen documentados, no desplegados.
